long long * setting();
long long * wsetting();
int daysetting(int);
long long * resetting();
long long *rwsetting();